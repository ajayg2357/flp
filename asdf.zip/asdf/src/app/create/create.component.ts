import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  user: Product;
constructor(private productService:ProductServiceService) 
{  this.user =new Product();}
   
  ngOnInit() {
  }

  createProductAccount(data):void {
   
    this.user.brand_id=data.brand_id;
    this.user.name=data.name;
    this.user.category=data.category;
    this.user.description=data.description;
    this.user.price=data.price;
    this.user.discount=data.discount;
    this.user.conprice=data.conprice;
    this.user.charges=data.charges;
    this.user.tax=data.tax;
    this.user.promo=data.promo;
    this.user.quantity=data.quantity;
console.log(this.user);
    this.productService.createProduct(this.user).subscribe(data => {
    alert("Account created successfully.");
    });
}
}

