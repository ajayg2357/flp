import { Component, OnInit, Injector, RootRenderer, Injectable } from '@angular/core';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-show-products',
  templateUrl: './show-products.component.html',
  styleUrls: ['./show-products.component.css']

})
@Injectable({
  providedIn:'root'
})

export class ShowProductsComponent implements OnInit {
   
  id:number;
  constructor(private productService : ProductServiceService) { }

  ngOnInit() {
  }


  showProducts(data): number
  {
    console.log(this.id);  

  this.productService.showProducts(data.id).subscribe(data=>{
    this.productService;
    console.log(this.productService)


  
})
return this.id;
  }
}
