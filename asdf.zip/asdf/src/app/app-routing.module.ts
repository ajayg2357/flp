import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateComponent } from './create/create.component';
import { ShowProductsComponent } from './show-products/show-products.component';
import { UpdateComponent } from './update/update.component';
import { DeleteComponent } from './delete/delete.component';

import { ViewComponent } from './view/view.component';


const routes: Routes =
 [
 {path:'view',
  component:ViewComponent},
{path:'create',
component:CreateComponent},
{path:'products',
component:ShowProductsComponent},
{path:'update',
component:UpdateComponent},
{path:'delete',
component:DeleteComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
