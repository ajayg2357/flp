import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  url = 'http://localhost:8054/delete';

 constructor(private httpClient:HttpClient) { }
 
 public showProducts(userDetails)
 {
 console.log(userDetails);
 return this.httpClient.get<Product>("http://localhost:8054/view/{id}" ,userDetails)
 }

 
 public createProduct(userDetails) {
   console.log(userDetails);
 return this.httpClient.post<Product>("http://localhost:8054/create", userDetails);
 }

 public updateProduct(id): Observable<number>
 {
 console.log(id);
 let url = 'http://localhost:8054/update/{id}'+id+'/';
 return this.httpClient.put<number>(url,"");
 }
 
 public deleteProduct(id:number): Observable<any>
 {
 console.log(id);
 //let url = 'http://localhost:8054/delete/{id}'+id+'/';
 return this.httpClient.delete<void>(`${this.url}/${id}`);
 }




 
 
}

3