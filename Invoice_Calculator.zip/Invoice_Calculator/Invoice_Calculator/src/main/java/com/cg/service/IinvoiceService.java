package com.cg.service;

import java.util.List;

import com.cg.bean.Invoice;

public interface IinvoiceService {
	
	

	
	List<Invoice> viewAllInvoice();
	Invoice createInvoice(Invoice obj);
	Invoice updateInvoice(Invoice obj, int id);
	void deleteInvoice(int i);
	Invoice findSingleInvoice(int id);

}
