package com.cg.dao;


public abstract class InvoiceRepoImpl implements IinvoiceRepo {

		
	}

	