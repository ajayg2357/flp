package com.cg.service;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Invoice;
import com.cg.dao.IinvoiceRepo;
import com.cg.dao.InvoiceRepoImpl;
@Service
public class InvoiceServiceImpl implements IinvoiceService {
	@Autowired
	IinvoiceRepo dao;
	
	static Scanner sc = new Scanner(System.in);
	@Override
	public Invoice createInvoice(Invoice obj) {

		obj.setId((int )(Math.random() * 1000 + 1));
		double d=5*obj.getDistance()*obj.getWeight();
		obj.setCgst(0.035*d);
		obj.setSgst(0.035*d);
		double amt=obj.getCgst()+obj.getSgst()+d;
		
		obj.setAmount(amt);
		
		return dao.save(obj);
	}

	@Override
	public Invoice updateInvoice(Invoice obj,int id) {
		
		
		Optional<Invoice> obj1 =dao.findById(id);
		if(obj1.isPresent())
		{
			Invoice i = obj1.get();
			i.setDistance(obj.getDistance());
			i.setWeight(obj.getWeight());
			double d=5*obj.getDistance()*obj.getWeight();
			obj.setCgst(0.035*d);
			obj.setSgst(0.035*d);
			double amt=obj.getCgst()+obj.getSgst()+d;
			
			obj.setAmount(amt);
			
			dao.save(i);
			return i;
		}
		return null;
		
	}

	@Override
	public void deleteInvoice(int id) {
		dao.deleteById(id);
		
	}

	@Override
	public List<Invoice> viewAllInvoice() {
		
		return dao.findAll();
	}

	@Override
	public Invoice findSingleInvoice(int id) {
		
		return dao.findById(id).get();
	}

}
